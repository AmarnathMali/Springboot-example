package com.example.warApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
