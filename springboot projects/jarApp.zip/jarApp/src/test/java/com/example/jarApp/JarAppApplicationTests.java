package com.example.jarApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JarAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
