package com.example.jarApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JarAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(JarAppApplication.class, args);
	}

}
