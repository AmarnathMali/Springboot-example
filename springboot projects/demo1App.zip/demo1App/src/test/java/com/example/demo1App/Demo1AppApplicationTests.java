package com.example.demo1App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo1AppApplicationTests {

	@Test
	void contextLoads() {
	}

}
