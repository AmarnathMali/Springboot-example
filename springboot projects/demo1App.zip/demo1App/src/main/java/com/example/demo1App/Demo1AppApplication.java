package com.example.demo1App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo1AppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo1AppApplication.class, args);
	}

}
